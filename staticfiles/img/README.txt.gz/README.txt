Place your profile photo for the hero here and name it `andi.jpg`:

main/static/img/andi.jpg.jpg

Tip: Use a square image, at least 600x600, and it will be cropped to a circle via CSS. If you want me to crop, upload your photo and say "crop and add to project" and I'll add it for you.